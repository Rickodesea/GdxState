package com.algodal.library.gdxstate.demogame;

public class RandomDataC {
	private Integer count;
	private RandomDataA a;
	private String[] list;
	
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public RandomDataA getA() {
		return a;
	}
	public void setA(RandomDataA a) {
		this.a = a;
	}
	public String[] getList() {
		return list;
	}
	public void setList(String[] list) {
		this.list = list;
	}
}
