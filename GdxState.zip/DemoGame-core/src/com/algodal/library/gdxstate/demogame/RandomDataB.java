package com.algodal.library.gdxstate.demogame;

public class RandomDataB {
	private float what;
	private long who;
	private String name;
	
	public float getWhat() {
		return what;
	}
	public void setWhat(float what) {
		this.what = what;
	}
	public long getWho() {
		return who;
	}
	public void setWho(long who) {
		this.who = who;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
