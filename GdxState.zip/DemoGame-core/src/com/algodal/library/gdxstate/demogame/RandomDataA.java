package com.algodal.library.gdxstate.demogame;

public class RandomDataA {
	private boolean cake;
	private boolean soda;
	private int guests;
	
	public boolean isCake() {
		return cake;
	}
	public void setCake(boolean cake) {
		this.cake = cake;
	}
	public boolean isSoda() {
		return soda;
	}
	public void setSoda(boolean soda) {
		this.soda = soda;
	}
	public int getGuests() {
		return guests;
	}
	public void setGuests(int guests) {
		this.guests = guests;
	}
	
	
}
