/*******************************************************************************
 * Copyright (c) 2016 Alrick Grandison (Algodal) <alrickgrandison@gmail.com>.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Mozilla Public License 2.0 
 * which accompanies this distribution, and is available at  
 * https://mozilla.org/MPL/2.0/
 * 
 * Contributors:
 *     Alrick Grandison (Algodal) <alrickgrandison@gmail.com> - initial API and implementation
 ******************************************************************************/
package com.algodal.library.gdxstate;

import com.badlogic.gdx.utils.ArrayMap;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.GdxRuntimeException;
import com.badlogic.gdx.utils.ObjectMap.Entry;

/**
 * 
 * @author Alrick Grandison (Algodal) <alrickgrandison@gmail.com>
 * @since October 21, 2016
 * @version 0.0.1
 *
 */
class Component implements Disposable{
	final ArrayMap<String, Object> am;
	final Share share;
	
	public Component(){
		am = new ArrayMap<String, Object>();
		share = new Share();
	}
	
	public final class Share{
		public final Object get(String ref){
			if(am.containsKey(ref))
					return am.get(ref);
			throw new GdxRuntimeException("The is no component of that reference");
		}
	}

	@Override
	public void dispose() {
		for(Entry<String, Object> entry : am){
			if(entry.value instanceof Disposable)
				((Disposable)entry.value).dispose();
		}
	}
}
