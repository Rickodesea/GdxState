/*******************************************************************************
 * Copyright (c) 2016 Alrick Grandison (Algodal) <alrickgrandison@gmail.com>.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Mozilla Public License 2.0 
 * which accompanies this distribution, and is available at  
 * https://mozilla.org/MPL/2.0/
 * 
 * Contributors:
 *     Alrick Grandison (Algodal) <alrickgrandison@gmail.com> - initial API and implementation
 ******************************************************************************/
package com.algodal.library.gdxstate;

/**
 * An information wrapper that wraps around the state class and its assets and pass the
 * information to the renderer.
 * @author Alrick Grandison (Algodal) <alrickgrandison@gmail.com>
 * @since October 21, 2016
 * @version 0.0.1
 *
 */
public final class GdxStateDescriptor {
	public final Class<?> clazz;
	public final AssetLabel<?>[] a;
	
	/**
	 * 
	 * @param clazz State class
	 * @param assets assets of the state
	 */
	public <T extends GdxState>GdxStateDescriptor(Class<T> clazz, AssetLabel<?> ... assets){
		this.clazz = clazz;
		a = assets;
	}

	@Override
	public boolean equals(Object obj) {
		return clazz.equals(((GdxStateDescriptor)obj).clazz);
	}

	@Override
	public String toString() {
		String clz = clazz.toString();
		if(a.length > 0) clz += ": ";
		for(int i = 0; i < a.length; i++){
			AssetLabel<?> l = a[i];
			if(l.label != null) clz += l.label + "<-->" + l.fileName;
			else clz += l.fileName;
			if(i < (a.length - 1)) clz += ", ";
		}
		return clz;
	}
	
}
